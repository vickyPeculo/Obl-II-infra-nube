const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

// crea el cliente en la región actual (Lambda setea AWS_REGION)
const sns = new SNSClient({ region: process.env.AWS_REGION });

exports.handler = async (event) => {
  const topicArn = process.env.SNS_TOPIC_ARN;
  const records  = (event && event.Records) ? event.Records : [];

  const titles = [];
  for (const rec of records) {
    try {
      const body = JSON.parse(rec.body || "{}");
      if (body && body.title) titles.push(body.title);
    } catch (_) { /* ignorar parse y seguir */ }
  }

  const total  = records.length;
  const titled = titles.length;

  const subject = titled > 0
    ? "Nuevo" + (titled > 1 ? "s" : "") +
      " artículo" + (titled > 1 ? "s" : "") +
      " generado" + (titled > 1 ? "s" : "") +
      " (" + titled + ")"
    : "Mensajes procesados (" + total + ")";

  const message =
    "Se procesaron " + total + " mensaje(s) de SQS.\\n" +
    (titled > 0 ? "Títulos: " + titles.join(", ") : "Sin títulos detectados.");

  try {
    await sns.send(new PublishCommand({
      TopicArn: topicArn,
      Subject:  subject,
      Message:  message
    }));
    console.log("Notificación enviada:", subject);
    return { ok: true, processed: total };
  } catch (err) {
    console.error("Error publicando en SNS:", err && (err.stack || err.message || err));
    throw err; // para que CloudWatch cuente el error (alarma)
  }
};
