const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { SQSClient, SendMessageCommand } = require("@aws-sdk/client-sqs");
const crypto = require("crypto");

const s3  = new S3Client({ region: process.env.AWS_REGION });
const sqs = new SQSClient({ region: process.env.AWS_REGION });

// Generador automático sin IA
function generateArticle(topic) {
  const body =
    "<h2>Introducción</h2>\n" +
    "<p>Este artículo fue generado automáticamente a partir del tópico <strong>" + topic + "</strong>.</p>\n" +
    "<h2>Desarrollo</h2>\n" +
    "<p>En esta sección se presentan conceptos relevantes, explicaciones funcionales y detalles técnicos relacionados con el tema.</p>\n" +
    "<p>El objetivo es proveer información clara y estructurada sin depender de ningún modelo de IA externa.</p>\n" +
    "<h2>Conclusión</h2>\n" +
    "<p>Este artículo demuestra la capacidad del sistema de generar contenido de forma automática, desacoplada y sin interacción directa con el servicio principal.</p>\n";

  return {
    title: "Artículo sobre: " + topic,
    body,
    createdAt: new Date().toISOString(),
    source: "template"
  };
}

exports.handler = async (event) => {
  const records = event.Records ?? [];

  for (const r of records) {
    const req   = JSON.parse(r.body || "{}");
    const topic = req.topic || "Tema sin título";
    const id    = req.id || crypto.randomUUID();

    const now  = new Date();
    const yyyy = now.getUTCFullYear();
    const mm   = String(now.getUTCMonth() + 1).padStart(2, "0");
    const dd   = String(now.getUTCDate()).padStart(2, "0");
    const key  = yyyy + "/" + mm + "/" + dd + "/" + id + ".json";

    const generated = generateArticle(topic);

    await s3.send(new PutObjectCommand({
      Bucket: process.env.ARTICLES_BUCKET,
      Key: key,
      Body: JSON.stringify(generated, null, 2),
      ContentType: "application/json"
    }));

    await sqs.send(new SendMessageCommand({
      QueueUrl: process.env.NOTIFY_QUEUE_URL,
      MessageBody: JSON.stringify({ title: generated.title, id })
    }));

    console.log("Artículo generado y guardado:", key);
  }

  return { ok: true, processed: records.length };
};
